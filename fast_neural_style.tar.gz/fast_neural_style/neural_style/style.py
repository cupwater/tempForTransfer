import argparse
import os
import sys
import time
import re

import numpy as np
import torch
from torchvision import transforms

import utils
from transformer_net import TransformerNet
from vgg import Vgg16

device = torch.device("cuda")

def stylize(content_dir, content_name, output_dir, style_model):
    content_image = utils.load_image(content_dir + content_name, scale=None)
    content_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Lambda(lambda x: x.mul(255))
    ])
    content_image = content_transform(content_image)
    content_image = content_image.unsqueeze(0).to(device)
    output = style_model(content_image).cpu()
    print(output_dir)
    print(content_name)
    utils.save_image(output_dir + content_name, output[0])


def main():
    main_arg_parser = argparse.ArgumentParser(description="parser for fast-neural-style")
    subparsers = main_arg_parser.add_subparsers(title="subcommands", dest="subcommand")

    eval_arg_parser = subparsers.add_parser("eval", help="parser for evaluation/stylizing arguments")
    
    eval_arg_parser.add_argument("--content-dir", type=str, required=True,
                                 help="path to content image you want to stylize")
    eval_arg_parser.add_argument("--output-dir", type=str, required=True,
                                 help="path for saving the output image")
    eval_arg_parser.add_argument("--model", type=str, required=True,
                                 help="saved model to be used for stylizing the image. If file ends in .pth - PyTorch path is used, if in .onnx - Caffe2 path")
    eval_arg_parser.add_argument("--cuda", type=int, required=True,
                                 help="set it to 1 for running on GPU, 0 for CPU")
    
    args = main_arg_parser.parse_args()

    with torch.no_grad():
        style_model = TransformerNet()
        state_dict = torch.load(args.model)
        # remove saved deprecated running_* keys in InstanceNorm from the checkpoint
        for k in list(state_dict.keys()):
            if re.search(r'in\d+\.running_(mean|var)$', k):
                del state_dict[k]
        style_model.load_state_dict(state_dict)
        style_model.to(device)


        for root, dirs, files in os.walk(args.content_dir):      
            for f in files: 
                stylize(args.content_dir, f, args.output_dir, style_model)


if __name__ == "__main__":
    main()

